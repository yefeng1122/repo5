create function fdna(dno dept.deptno%type) return dept.dname%type
is
    dna dept.dname%type;
begin
    select dname into dna from dept where deptno=dno;
    return dna;-- 将查到的部门名返回
end;
/

