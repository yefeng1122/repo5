create function f_yearsal(eno emp.empno%type) return number
as
    s number(10); --用于保存年薪
begin
    select sal*12+nvl(comm,0) into s from emp where emp.empno = eno;
    return s; --返回年薪
end;
/

