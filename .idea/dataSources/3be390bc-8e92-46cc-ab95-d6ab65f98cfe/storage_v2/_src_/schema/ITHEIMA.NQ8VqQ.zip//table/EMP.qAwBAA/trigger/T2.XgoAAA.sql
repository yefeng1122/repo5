create trigger T2
  before update
  on EMP
  for each row
  declare
begin
    if :new.sal<:old.sal then --当新工资小于原来的工资时 执行的代码
        raise_application_error(-20001,'不能给员工降薪');  -- 抛异常 并且给出提示信息
    end if;
end;
/

