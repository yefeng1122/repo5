create view V_EMP as
  (select e.empno,e.ename from emp e)
/

