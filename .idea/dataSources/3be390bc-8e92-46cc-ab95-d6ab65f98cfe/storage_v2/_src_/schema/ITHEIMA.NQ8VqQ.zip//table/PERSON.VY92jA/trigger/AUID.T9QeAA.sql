create trigger AUID
  before insert
  on PERSON
  for each row
  declare
begin
    select s_person.nextval into :new.pid from dual; -- 将序列中值赋给即将要插入记录的主键
end;
/

