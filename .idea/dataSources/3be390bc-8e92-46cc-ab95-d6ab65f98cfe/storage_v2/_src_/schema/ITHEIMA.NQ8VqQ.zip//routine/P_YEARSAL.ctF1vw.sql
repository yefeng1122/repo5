create procedure p_yearsal(eno in emp.empno%type,yearsal out number)
is
    s number(10);
begin
    select sal*12+nvl(comm,0) into s from emp where emp.empno = eno;
    yearsal := s; -- 为输出型变量赋值
end;
/

