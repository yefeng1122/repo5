create trigger T1
  after insert
  on PERSON
  declare
begin
    dbms_output.put_line('一个新员工入职');  --触发器执行的代码
end;
/

